# Gen 1 Crossing starter (source only, UNTESTED, NOT BUILT)

Written without access to your PC, the recomp, Melty, or a network. Nothing here has been compiled or run.

Bridge: both sides share a folder (env GEN1X_BRIDGE, default ~/.gen1crossing).
- Recomp writes enter.txt (one species name per line) when the player enters the portal.
- Fabric mod spawns those as named mobs near the player. Right-click one to catch it.
- Mod appends the name to caught.txt; the recomp reads it in love.update and adds it to the party.

Still to do on your PC: adapt love/crossing.lua to the recomp's real code, build the mod
(`gradle build`, versions unverified), render real sprites from the player's own recomp
folder (not copied), put it in a Prism instance, write the Melty recipe (recomp = primary,
Minecraft = companion, recipe.together, GEN1X_BRIDGE env), screenshot, test_release.
