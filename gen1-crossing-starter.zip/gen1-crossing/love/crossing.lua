-- Gen 1 Crossing: LÖVE side of the bridge. UNTESTED source.
-- Drop into the recomp's Lua source and require it. No game assets are copied:
-- species names come from the recomp's own data at runtime.
local C = {}

local dir = os.getenv("GEN1X_BRIDGE")
  or ((os.getenv("USERPROFILE") or os.getenv("HOME") or ".") .. "/.gen1crossing")
local timer = 0

-- Call when the player steps into the portal tile. `species` is a list of
-- species names read from the recomp's own data (e.g. the current area's encounter table).
function C.enter(species)
  local f = io.open(dir .. "/enter.txt", "w")
  if not f then return false end
  for _, name in ipairs(species) do f:write(name, "\n") end
  f:close()
  return true
end

-- Call from love.update(dt). `onCaught(name)` should add the monster to the party.
function C.update(dt, onCaught)
  timer = timer + dt
  if timer < 0.5 then return end
  timer = 0
  local path = dir .. "/caught.txt"
  local f = io.open(path, "r")
  if not f then return end
  local names = {}
  for line in f:lines() do if line ~= "" then names[#names + 1] = line end end
  f:close()
  os.remove(path)
  for _, name in ipairs(names) do onCaught(name) end
end

return C
