package gg.melty.gen1crossing;

// Gen 1 Crossing: Minecraft side of the bridge. UNTESTED source (not compiled).
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;

public class Gen1Crossing implements ModInitializer {
    private static final String TAG = "gen1x";
    private static Path bridge;
    private int ticks = 0;

    @Override
    public void onInitialize() {
        String env = System.getenv("GEN1X_BRIDGE");
        bridge = Path.of(env != null ? env : System.getProperty("user.home") + "/.gen1crossing");
        try { Files.createDirectories(bridge); } catch (IOException ignored) {}

        ServerTickEvents.END_SERVER_TICK.register(this::tick);

        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient || hand != Hand.MAIN_HAND || !entity.getCommandTags().contains(TAG)) {
                return ActionResult.PASS;
            }
            String name = entity.getCustomName() != null ? entity.getCustomName().getString() : "";
            entity.discard();
            try {
                Files.writeString(bridge.resolve("caught.txt"), name + "\n",
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException ignored) {}
            player.sendMessage(Text.literal("Caught " + name + "!"), true);
            return ActionResult.SUCCESS;
        });
    }

    private void tick(MinecraftServer server) {
        if (++ticks % 20 != 0) return;
        Path enter = bridge.resolve("enter.txt");
        if (!Files.exists(enter)) return;
        List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
        if (players.isEmpty()) return; // keep the file until a player is in the world
        try {
            List<String> species = Files.readAllLines(enter);
            Files.delete(enter);
            ServerPlayerEntity p = players.get(0);
            ServerWorld w = p.getServerWorld();
            int i = 0;
            for (String name : species) {
                if (name.isBlank()) continue;
                // Placeholder body; real Gen 1 sprites are the next step.
                Entity e = EntityType.RABBIT.create(w);
                if (e == null) continue;
                double angle = i++ * 0.9;
                e.refreshPositionAndAngles(p.getX() + Math.cos(angle) * 6, p.getY(),
                        p.getZ() + Math.sin(angle) * 6, 0, 0);
                e.setCustomName(Text.literal(name));
                e.setCustomNameVisible(true);
                e.addCommandTag(TAG);
                if (e instanceof MobEntity m) m.setPersistent();
                w.spawnEntity(e);
            }
        } catch (IOException ignored) {}
    }
}
